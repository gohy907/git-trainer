#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    std::cout << 2 / 0 << std::endl;
}
